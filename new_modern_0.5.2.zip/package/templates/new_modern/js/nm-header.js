/**
 * New Modern: шапка (виджет «Шапка New Modern»).
 * 1. Кнопки data-nm-toggle="panel" и "search" раскрывают меню и форму поиска. Повторное нажатие сворачивает.
 *    Открытие одного блока закрывает другой.
 * 2. У пунктов со вложенными списками (меню бургера в режиме «с вложениями» и меню пользователя)
 *    появляется стрелка раскрытия.
 * 3. Прилипание: classic / center закрепляют ряд с меню, line закрепляет всю строку.
 * Без JS шапка остаётся обычной, страница работает.
 */
(function () {
    'use strict';

    var MOBILE = window.matchMedia ? window.matchMedia('(max-width: 991.98px)') : { matches: false };

    function blockFor(root, name) {
        return root.querySelector(name === 'panel' ? '.nm-hw__panel' : '.nm-hw__search-drop');
    }

    function setOpen(root, name, open) {
        var block = blockFor(root, name);
        if (!block) { return; }
        block.classList.toggle('is-open', open);
        var buttons = root.querySelectorAll('[data-nm-toggle="' + name + '"]');
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        if (open && name === 'search') {
            var input = block.querySelector('input[name="q"]');
            if (input) { input.focus(); }
        }
    }

    function initToggles(root) {
        var buttons = root.querySelectorAll('[data-nm-toggle]');
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].addEventListener('click', function (e) {
                e.preventDefault();
                var name  = this.getAttribute('data-nm-toggle');
                var other = name === 'panel' ? 'search' : 'panel';
                var block = blockFor(root, name);
                if (!block) { return; }
                var open = !block.classList.contains('is-open');
                setOpen(root, name, open);
                if (open) { setOpen(root, other, false); }
            });
        }

        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') { return; }
            setOpen(root, 'panel', false);
            setOpen(root, 'search', false);
        });
    }

    function isDummyLink(a) {
        var href = a.getAttribute('href');
        return !href || href === '#' || href.indexOf('javascript:') === 0;
    }

    // Ссылки со вложенными списками работают как обычные ссылки (Bootstrap-переключатель снимаем).
    // Если accordion, рядом с таким пунктом появляется стрелка раскрытия.
    function enhanceMenu(scope, accordion, label) {
        var drops = scope.querySelectorAll('[data-toggle]');
        for (var d = 0; d < drops.length; d++) { drops[d].removeAttribute('data-toggle'); }

        var items = scope.querySelectorAll('li');

        for (var i = 0; i < items.length; i++) {
            var li   = items[i];
            var sub  = null;
            var link = null;
            for (var c = 0; c < li.children.length; c++) {
                var tag = li.children[c].tagName;
                if (tag === 'UL' && !sub) { sub = li.children[c]; }
                if (tag === 'A' && !link) { link = li.children[c]; }
            }
            if (!sub) { continue; }

            li.classList.add('has-sub');
            if (!accordion) { continue; }

            if (li.classList.contains('active') || sub.querySelector('.active')) {
                li.classList.add('is-sub-open');
            }

            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'nm-hw__sub-toggle';
            btn.setAttribute('aria-label', label);
            btn.setAttribute('aria-expanded', li.classList.contains('is-sub-open') ? 'true' : 'false');

            var toggle = (function (item, button) {
                return function (e) {
                    // Не даём внешнему выпадающему списку закрыться от этого нажатия
                    e.stopPropagation();
                    var open = item.classList.toggle('is-sub-open');
                    button.setAttribute('aria-expanded', open ? 'true' : 'false');
                };
            })(li, btn);

            btn.addEventListener('click', toggle);

            // Пункт без своего адреса раскрывает подпункты по нажатию на сам текст
            if (link && isDummyLink(link)) {
                link.addEventListener('click', function (handler) {
                    return function (e) { e.preventDefault(); handler(e); };
                }(toggle));
            }

            li.insertBefore(btn, sub);
        }
    }

    function initMenus(root) {
        var label = root.getAttribute('data-nm-submenu-label') || '';

        var panel = root.querySelector('.nm-hw__panel');
        if (panel) {
            enhanceMenu(panel, root.classList.contains('nm-hw--mm-accordion'), label);
        }

        var userMenus = root.querySelectorAll('.nm-hw__user-menu');
        for (var i = 0; i < userMenus.length; i++) {
            enhanceMenu(userMenus[i], true, label);
        }
    }

    function initSticky(root) {
        if (root.getAttribute('data-nm-sticky') !== '1') { return; }

        var sticky   = root.querySelector('.nm-hw__sticky');
        var sentinel = root.querySelector('.nm-hw__sentinel');
        if (!sticky || !sentinel) { return; }

        var allowMobile = root.getAttribute('data-nm-sticky-mobile') === '1';
        var spacer = document.createElement('div');
        spacer.className = 'nm-hw__spacer';
        sticky.parentNode.insertBefore(spacer, sticky);

        function enabled() { return !MOBILE.matches || allowMobile; }

        function stick() {
            if (root.classList.contains('is-stuck')) { return; }
            spacer.style.height = sticky.offsetHeight + 'px';
            root.classList.add('is-stuck');
        }

        function unstick() {
            if (!root.classList.contains('is-stuck')) { return; }
            root.classList.remove('is-stuck');
            spacer.style.height = '0px';
        }

        function check() {
            if (!enabled() || sticky.offsetHeight === 0) { unstick(); return; }
            var top = sentinel.getBoundingClientRect().top;
            var offset = parseInt(getComputedStyle(root).getPropertyValue('--nm-hw-top'), 10) || 0;
            if (top < offset) { stick(); } else { unstick(); }
        }

        var ticking = false;
        function onScroll() {
            if (ticking) { return; }
            ticking = true;
            window.requestAnimationFrame(function () { ticking = false; check(); });
        }

        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', function () { unstick(); check(); });
        check();
    }

    function boot() {
        var roots = document.querySelectorAll('.nm-hw');
        for (var i = 0; i < roots.length; i++) {
            initToggles(roots[i]);
            initMenus(roots[i]);
            initSticky(roots[i]);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
