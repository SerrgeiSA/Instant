<?php
if (!$is_frontpage){
    if (cmsUser::isAllowed($ctype['name'], 'add')) {

        if (!$category['id'] || $user->isInGroups($category['allow_add'])){

            $href = href_to($ctype['name'], 'add', isset($category['path']) ? $category['id'] : '');

            $this->addToolButton([
                'icon' => 'plus-circle',
                'title' => sprintf(LANG_CONTENT_ADD_ITEM, $ctype['labels']['create']),
                'href'  => $href
            ]);
        }
    }

    if ($ctype['is_cats']){
        if (cmsUser::isAllowed($ctype['name'], 'add_cat')) {
            $this->addToolButton([
                'icon' => 'folder-plus',
                'title' => LANG_ADD_CATEGORY,
                'href'  => href_to($ctype['name'], 'addcat', $category['id'])
            ]);
        }

        if ($category['id']){

            if (cmsUser::isAllowed($ctype['name'], 'edit_cat')) {
                $this->addToolButton([
                    'icon'  => 'edit',
                    'title' => LANG_EDIT_CATEGORY,
                    'href'  => href_to($ctype['name'], 'editcat', $category['id'])
                ]);
            }
            if (cmsUser::isAllowed($ctype['name'], 'delete_cat')) {
                $this->addToolButton([
                    'icon'  => 'folder-minus',
                    'title' => LANG_DELETE_CATEGORY,
                    'href'  => href_to($ctype['name'], 'delcat', $category['id']),
                    'data'  => ['confirm' => LANG_DELETE_CATEGORY_CONFIRM]
                ]);
            }

        }
    }

    if (cmsUser::isAdmin()){
        $this->addToolButton([
            'icon' => 'wrench',
            'title' => sprintf(LANG_CONTENT_TYPE_SETTINGS, mb_strtolower($ctype['title'])),
            'href'  => href_to('admin', 'ctypes', ['edit', $ctype['id']])
        ]);
    }
}

?>
<?php ob_start(); ?>
    <?php if ($show_h1){  ?>
        <h1>
            <?php $this->pageH1(); ?>
            <?php if (!empty($ctype['rss_link'])){ ?>
                <sup>
                    <a class="inline_rss_icon d-none d-lg-inline-block" title="RSS" href="<?php echo $ctype['rss_link']; ?>">
                        <?php html_svg_icon('solid', 'rss'); ?>
                    </a>
                </sup>
            <?php } ?>
        </h1>
    <?php } ?>
    <?php if (!empty($list_styles)){ ?>
        <?php
            // New Modern: иконки для всех стилей, у неизвестных — запасная
            $list_icons_mapping = [
                '' => 'list', 'featured' => 'newspaper', 'table' => 'table', 'tiles' => 'th',
                'nm_cards' => 'th-large', 'nm_overlay' => 'images', 'nm_horizontal' => 'th-list',
                'nm_magazine' => 'newspaper', 'nm_news' => 'stream', 'nm_compact' => 'bars',
                'nm_board' => 'list', 'nm_board_grid' => 'th', 'nm_catalog' => 'store',
                'nm_catalog_rows' => 'building', 'nm_timeline' => 'history', 'nm_top' => 'list-ol',
                'nm_masonry' => 'columns'
            ];
            // Названия: из «Названий стилей» типа контента, иначе из шаблона
            $nm_style_names = $this->getAvailableContentListStyles();
            $nm_current = null;
            foreach ($list_styles as $k => $list_style) {
                if (!$list_style['title']) {
                    $t = $nm_style_names[$list_style['style']] ?? $list_style['style'];
                    $list_styles[$k]['title'] = trim(preg_replace('/\s*\([^)]*\)$/', '', preg_replace('/^NM:\s*/', '', $t)));
                }
                $list_styles[$k]['icon'] = $list_icons_mapping[$list_style['style']] ?? 'th-large';
                $list_styles[$k]['is_active'] = strpos($list_style['class'], ' active') !== false;
                if ($list_styles[$k]['is_active']) { $nm_current = $list_styles[$k]; }
            }
            if (!$nm_current) { $nm_current = reset($list_styles); }
        ?>
        <?php if (count($list_styles) <= 5) { ?>
            <div class="icms-content-list__styles_btn nm-styles btn-group" role="group">
                <?php foreach ($list_styles as $list_style) { ?>
                <a data-toggle="tooltip" data-placement="top" rel="nofollow" href="<?php echo $list_style['url']; ?>" class="btn btn-light icms-content-list__<?php echo $list_style['class']; ?>" title="<?php html($list_style['title']); ?>" aria-label="<?php html($list_style['title']); ?>"<?php if ($list_style['is_active']) { ?> aria-current="true"<?php } ?>>
                    <?php html_svg_icon('solid', $list_style['icon']); ?>
                </a>
                <?php } ?>
            </div>
        <?php } else { ?>
            <div class="icms-content-list__styles_btn nm-styles dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php html_svg_icon('solid', $nm_current['icon']); ?>
                    <span class="d-none d-sm-inline"><?php html($nm_current['title']); ?></span>
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <?php foreach ($list_styles as $list_style) { ?>
                    <a rel="nofollow" href="<?php echo $list_style['url']; ?>" class="dropdown-item<?php if ($list_style['is_active']) { ?> active<?php } ?>">
                        <?php html_svg_icon('solid', $list_style['icon']); ?> <?php html($list_style['title']); ?>
                    </a>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    <?php } ?>
<?php $this->addToBlock('before_body', ob_get_clean(), true); ?>

<?php if ($datasets && !$is_hide_items){
    $tpl_file = $this->getTemplateFileName('assets/ui/datasets-panel_' . $ctype['name'], true) ? 'ui/datasets-panel_' . $ctype['name'] : 'ui/datasets-panel';
    $this->renderAsset($tpl_file, [
        'datasets'        => $datasets,
        'dataset_name'    => $dataset,
        'current_dataset' => $current_dataset,
        'wrap_class'      => ($show_h1 ? 'my-3 my-md-4' : 'mb-3 mb-md-4').' content_datasets_'.$ctype['name'],
        'ds_prefix'       => '-',
        'base_ds_url'     => rel_to_href($base_ds_url)
    ]);
} ?>

<?php if (!empty($category['description'])){?>
    <div class="category_description"><?php echo $category['description']; ?></div>
<?php } ?>

<?php if ($subcats){ ?>
    <?php if($ctype['options']['cover_preset']){ ?>
        <div class="row mb-n3">
            <?php foreach($subcats as $c){ ?>
                <div class="col-md-4 col-sm-6 mb-3 mb-md-4 <?php echo $c['list_params']['class']; ?>">
                    <div class="card border-0 bg-light">
                        <?php if($c['list_params']['cover_img']){ ?>
                            <a class="d-block overflow-hidden rounded-lg" href="<?php echo $c['list_params']['href']; ?>">
                                <img class="d-block w-100" src="<?php echo $c['list_params']['cover_img']; ?>" alt="<?php html($c['title']); ?>">
                            </a>
                        <?php } ?>
                        <div class="card-body">
                            <h2 class="h5 m-0">
                                <a href="<?php echo $c['list_params']['href']; ?>">
                                    <?php echo $c['title']; ?>
                                </a>
                                <?php if(isset($c['item_count_recursive'])){ ?>
                                    <small class="text-secondary mt-1 icms-content-subcats__count d-block">
                                        <?php echo html_spellcount(
                                                $c['item_count_recursive'],
                                                $ctype['labels']['one'],
                                                $ctype['labels']['two'],
                                                $ctype['labels']['many']
                                            ); ?>
                                    </small>
                                <?php } ?>
                            </h2>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    <?php } else { ?>
        <ul class="list-inline icms-content-subcats">
            <?php foreach($subcats as $c){ ?>
                <li class="list-inline-item h4 text-warning mr-3 <?php echo $c['list_params']['class']; ?>">
                    <?php html_svg_icon('solid', 'folder'); ?>
                    <a href="<?php echo $c['list_params']['href']; ?>">
                        <?php echo $c['title']; ?>
                    </a>
                    <?php if(isset($c['item_count_recursive'])){ ?>
                        <sup class="text-secondary icms-content-subcats__count">
                            <?php echo $c['item_count_recursive']; ?>
                        </sup>
                    <?php } ?>
                </li>
            <?php } ?>
        </ul>
    <?php } ?>
<?php } ?>

<?php $this->block('before_content_items_list_html'); ?>

<?php echo $items_list_html; ?>

<?php $this->block('after_content_items_list_html'); ?>

<?php if ($hooks_html) { ?>
    <div class="sub_items_list">
        <?php echo html_each($hooks_html); ?>
    </div>
<?php } ?>
